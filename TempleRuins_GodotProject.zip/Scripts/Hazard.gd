# กับดัก: แตะแล้วตายและเกิดใหม่ที่จุดเช็คพอยต์
extends Area3D

func _on_body_entered(body: Node3D) -> void:
	if body.is_in_group("Player") and body.has_method("die"):
		body.die()
